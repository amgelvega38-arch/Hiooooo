# Cambios EXTERNAL VIP

- Se actualizó la portada, el fondo del menú y la pantalla de acceso/canal con la imagen proporcionada.
- Los fondos se prepararon en proporción de pantalla para iPhone 13 (6.1 pulgadas, 1170 × 2532 @3x), conservando la foto completa sobre un fondo suavizado.
- Se cambió la identidad visible a EXTERNAL VIP.
- El ejemplo visual del campo de licencia ahora dice NRCK-xxxxxx; la validación de licencias no fue modificada.
